#ifndef _RADIXSPLINE_H_
#define _RADIXSPLINE_H_
//#pragma once

#include <cassert>
#include <cstdlib>
#include <iostream>
#include <map>
#include <stdexcept>
#include <utility>
#include<tuple>
#include <time.h>
#include <fstream>
#include <limits>
#include <climits>
#include <cmath>
#include <algorithm>
#include <vector>
#include "ap_int.h"
//#include "hls_vector.h"
#include <hls_stream.h>
#include "timer.h"
//#define TestNumber 20

/*
GEETESH:
For TestNumber: 100000
max_prefix = 16777081
*/


typedef ap_uint<32>  din_t;
typedef ap_uint<32>  din_t64;
typedef ap_uint<128>  din_t128;
//typedef int  din_t;
using std::numeric_limits;
using namespace std;
// A CDF coordinate.
template<class size_t>
struct Coord {
    size_t x;
    double y;
};

struct SearchBound {
    size_t begin;
    size_t end; // Exclusive.
};
//typedef hls::vector<Coord<size_t>, TestNumber> vec_t2;

class RadixSpline
{
public:
    RadixSpline(size_t start, size_t end,size_t vecSize,size_t numShiftBits,Coord<size_t>* spline_points_arr1,din_t& radix_table_1) :
        start(start),
        end(end),
        numRadixBit(0),
        numShiftBits(numShiftBits),
        maxSplineErr(0),
        currKeyCount(0),
        currDistinctKeyCnt(0),
        prevKey(start),
        prevKeyPos(0),
		spline_size(0),
		max_prefix(vecSize),
		boundStart(0),
		boundEnd(0),
        prevPrefix(0)
    {
        spline_points_arr = spline_points_arr1;
	radix_table_ = radix_table_1;
        numRadixBit = 18;
        maxSplineErr = 32;
    }

private:
    // Returns the index of the spline point that marks the end of the spline segment that contains the `key`:
    size_t GetSplineSegment(const size_t key) const {
        // Narrow search range using radix table.
        const size_t prefix = (key - start) >> numShiftBits;
        /*
		GEETESH: Commented assertion as :
		WARNING: [HLS 207-4615]
		the argument to '__builtin_assume' has side effects that will be discarded (././RadixSpline.h:70:27)
		*/
        //assert(prefix + 1 < getMaxPrefix());
        const uint32_t begin = radix_table_[prefix];
        const uint32_t end = radix_table_[prefix + 1];

        if (end - begin < 32) {
            // Do linear search over narrowed range.
            uint32_t current = begin;
            /*
            WARNING: [HLS 200-878] Unable to schedule the loop exit test ('icmp' operation ('icmp_ln77', ././RadixSpline.h:77))
            in the first pipeline iteration (II = 1 cycles).
            Resolution: For help on HLS 200-878 see www.xilinx.com/cgi-bin/docs/rdoc?v=2022.1;t=hls+guidance;d=200-878.html
            */
            size_t cmpVal = spline_points_arr[current].x;
            //std::cout<<"GEETESH: cmpVal: " << cmpVal << " ; key: " << key << std::endl;
            while (cmpVal < key)
            {
//#pragma HLS UNROLL
//#pragma HLS pipeline II=1
            	++current;
            	cmpVal = spline_points_arr[current].x;
            }
            //std::cout << " GEETESH: returning Val: " << current << std::endl;
            return current;
        }
        // Do binary search over narrowed range.
        const auto lb1 = std::lower_bound(spline_points_arr+begin,
        		spline_points_arr+end,
				key,
				[](const Coord<size_t>& coord, const size_t key) { return coord.x < key; });
        return std::distance(spline_points_arr,lb1);
    }
public:
    enum Orientation { Collinear, CW, CCW };
    static constexpr double precision = std::numeric_limits<double>::epsilon();

    static Orientation ComputeOrientation(const double dx1, const double dy1, const double dx2, const double dy2) {
        const double expr = std::fma(dy1, dx2, -std::fma(dy2, dx1, 0));
        if (expr > precision) return Orientation::CW;
        else if (expr < -precision) return Orientation::CCW;
        return Orientation::Collinear;
    };
    void SetUpperLimit(size_t key, double position) { upperBound = { key, position }; }
    void SetLowerLimit(size_t key, double position) { lowerBound = { key, position }; }
    //void RememberPreviousCDFPoint(size_t key, double position) { prev_point_ = { key, position }; }
    void FinalizeRadixTable()
    {
        ++prevPrefix;
        const uint32_t num_spline_points = getSplineSize();
        for (; prevPrefix < getMaxPrefix(); ++prevPrefix)
        {
            radix_table_[prevPrefix] = num_spline_points;
        }
    }
    void Finalize()
    {
        // Last key needs to be equal to `end`.
        //assert(currKeyCount == 0 || prevKey == end);
        // Ensure that `prevKey` (== `end`) is last key on spline.
        if (currKeyCount > 0 && spline_points_arr[getSplineSize()-1].x != prevKey)
        {
            AddKeyToSpline(prevKey, prevKeyPos);
        }
        FinalizeRadixTable();

    }

    void PossiblyAddKeyToRadixTable(size_t key) {
        const size_t curr_prefix = (key - start) >> numShiftBits;
        //std::cout << "GEETESH: start: " << start << " ; num_shift_bits_ : " << numShiftBits << " ; curr_prefix: " << curr_prefix << " ; prevPrefix: " << prevPrefix << std::endl;
        if (curr_prefix != prevPrefix) {
            const uint32_t curr_index = getSplineSize()-1;
            //const uint32_t curr_index = spline_points_.size() - 1;
            //std::cout<< "GEETESH: curr_index: " << curr_index << std::endl;
            for (size_t prefix = prevPrefix + 1; prefix <= curr_prefix; ++prefix)
            {
                radix_table_[prefix] = curr_index;
                //std::cout<<"GEETESH: radix_table_[" << prefix << "]: " << radix_table_[prefix] << std::endl;
            }
            //std::cout<<"GEETESH22: Done PossiblyAddKeyToRadixTable" << std::endl;
            prevPrefix = curr_prefix;
        }
    }

    void AddKeyToSpline(size_t key, double position) {
        //GEETESH: needed for HLS support. How to do RESIZE in HLS. Ask XILINX
    	size_t splineSize = getSplineSize();
    	spline_points_arr[splineSize].x = key;
    	spline_points_arr[splineSize].y = position;
    	//std::cout<<"GEETESH: spline_points_arr value at index (" << splineSize << ") : {" << spline_points_arr[splineSize].x << "," << spline_points_arr[splineSize].y << "}" << std::endl;

        //incrSplineSize();
        PossiblyAddKeyToRadixTable(key);
        incrSplineSize();
        //std::cout<<"GEETESH: DOne PossiblyAddKeyToRadixTable" << std::endl;
    }
    //Phase 3: Create Radix Spline:
    //  This function is taken from:
    // T. Neumann and S. Michel. Smooth interpolating histograms with error guarantees. [BNCOD'08]
    void neumannSpline(size_t key, double position)
    {
        //std::cout << "Adding key to spline: (curKeyCOunt,position,Key): " << currKeyCount << "," << position << "," << key << " ; maxSplineErr: " << maxSplineErr << std::endl;
        if (currKeyCount == 0) {
        	//std::cout<<"GEETESH: Add first CDF point to spline" << std::endl;
            // Add first CDF point to spline.
            AddKeyToSpline(key, position);
            //std::cout<<"GEETESH: Done AddKeyToSpline" << std::endl;
            ++currDistinctKeyCnt;
            //RememberPreviousCDFPoint(key, position);
            prev_point_ = { key, position };
            //std::cout<<"GEETESH: Done RememberPreviousCDFPoint" << std::endl;
            return;
        }

        if (key == prevKey) {
            // No new CDF point if the key didn't change.
            return;
        }

        // New CDF point.
        ++currDistinctKeyCnt;
       //std::cout<<"GEETESH: currDistinctKeyCnt: " << currDistinctKeyCnt << std::endl;

        if (currDistinctKeyCnt == 2) {
            // Initialize `upperBound` and `lowerBound` using the second CDF point.
            SetUpperLimit(key, position + maxSplineErr);
            SetLowerLimit(key, (position < maxSplineErr) ? 0 : position - maxSplineErr);
            //RememberPreviousCDFPoint(key, position);
            prev_point_ = { key, position };
            return;
        }

        // `B` in algorithm.
        //std::cout<<"GEETESH: getSplineSize: " << getSplineSize() << std::endl;
        const Coord<size_t>& last = spline_points_arr[getSplineSize()-1];
        //std::cout<<"GEETESH: last.x: " << last.x << " ; last.y: " << last.y << " ; getSplineSize: " << getSplineSize() << std::endl;

        // Compute current `upper_y` and `lower_y`.
        const double upper_y = position + maxSplineErr;
        const double lower_y = (position < maxSplineErr) ? 0 : position - maxSplineErr;

        // Compute differences.
        assert(upperBound.x >= last.x);
        assert(lowerBound.x >= last.x);
        //assert(key >= last.x);
        const double upperBoundx_diff = upperBound.x - last.x;
        const double lowerBoundx_diff = lowerBound.x - last.x;
        const double x_diff = key - last.x;

        assert(upperBound.y >= last.y);
        assert(position >= last.y);
        const double upperBoundy_diff = upperBound.y - last.y;
        const double lowerBoundy_diff = lowerBound.y - last.y;
        const double y_diff = position - last.y;
        //std::cout<<"GEETESH: y_diff = " << y_diff << std::endl;

        // `prev_point_` is the previous point on the CDF and the next candidate to be added to the spline.
        // Hence, it should be different from the `last` point on the spline.
        assert(prev_point_.x != last.x);

        // Do we cut the error corridor?
        if ((ComputeOrientation(upperBoundx_diff, upperBoundy_diff, x_diff, y_diff) != Orientation::CW)
            || (ComputeOrientation(lowerBoundx_diff, lowerBoundy_diff, x_diff, y_diff) != Orientation::CCW))
        {
            // Add previous CDF point to spline.
        	//std::cout<<"GEETESH: AddKeyToSpline again" << std::endl;
            AddKeyToSpline(prev_point_.x, prev_point_.y);
            //std::cout<<"GEETESH: Done AddKeyToSpline again" << std::endl;

            // Update limits.
            SetUpperLimit(key, upper_y);
            SetLowerLimit(key, lower_y);
        }
        else
        {
        	//std::cout<<"GEETESH2: AddKeyToSpline again" << std::endl;
            assert(upper_y >= last.y);
            const double upper_y_diff = upper_y - last.y;
            if (ComputeOrientation(upperBoundx_diff, upperBoundy_diff, x_diff, upper_y_diff) == Orientation::CW) {
                SetUpperLimit(key, upper_y);
            }

            const double lower_y_diff = lower_y - last.y;
            if (ComputeOrientation(lowerBoundx_diff, lowerBoundy_diff, x_diff, lower_y_diff) == Orientation::CCW) {
                SetLowerLimit(key, lower_y);
            }
        }

        //RememberPreviousCDFPoint(key, position);
        prev_point_ = { key, position };
    }

    //Phase2: Adds a key..
    //prevKeyPos is the previous point on the CDF and the next candidate to be added to the spline.
    // Hence, it should be different from the currKeyPos point on the spline.
    void AddKey(size_t key) {
        //std::cout << "; start: " << start << " ; end: " << end << " ; curr_num_keys_: " << currKeyCount << " ; prev_position_: " << prevKeyPos << " ; key: " << key << std::endl;

        size_t position;
        if (currKeyCount == 0) {
            position = currKeyCount;
            neumannSpline(key, position);
            ++currKeyCount;
            prevKey = key;
            prevKeyPos = position;
        }
        else
        {
        	//std::cout<<"GEETESH: start: " << start << " ; end: " << end << " ; key: " << key << std::endl;
            //assert(key >= start && key <= end);
            //assert(key >= prevKey);
            position = prevKeyPos + 1;
            assert(position == 0 || position > prevKeyPos);
            neumannSpline(key, position);
            ++currKeyCount;
            prevKey = key;
            prevKeyPos = position;
        }
    }

    //Phase1: Build Phase
    //Radix table will limit the search range on radix point
    //1. numRadixBit(r): controls the size of prefix lookup table: Size of radix table: 2^(r)
    //2. maxSplineErr(e): number of estimated positions that is off from lookup key
    //FOREACH ( KEY in SORTED KEY ) {
    //  if ( MAXSPLINE_ERR is exceeded ) {
    //      APPEND NEW SPLINE POINT
    //      if( NEW SPLINE POINT has  r-bit prefix ) {
    //          ADD PREFIX to TABLE
    //      }
    //   }
    //}
    void set_numShiftBit(size_t value)
    {
        numShiftBits = value;
    }
    size_t get_numShiftBit()
    {
        return numShiftBits;
    }
    void setMaxPrefix(size_t value)
    {
    	max_prefix = value;
    }
    size_t getMaxPrefix() const
    {
    	return max_prefix;
    }
    void incrSplineSize()
    {
    	spline_size++;
    }
    size_t getSplineSize() const
    {
    	return (spline_size);
    }
    void setBoundStart(size_t value)
    {
    	boundStart = value;
    }
    size_t getBoundStart() const
    {
    	return boundStart;
    }
    void setBoundEnd(size_t value)
    {
    	boundEnd = value;
    }
    size_t getBoundEnd() const
    {
    	return boundEnd;
    }
    
    Coord<size_t>* getSplinePoint() 
    {
        return spline_points_arr;
    }
    
    din_t getRadixTable() 
    {
        return radix_table_;
    }
    //Now search
    // Returns the estimated position of `key`.
    double GetEstimatedPosition(const size_t key) const {
        // Truncate to data boundaries.
        if (key <= start) return 0;
        if (key >= end) return currKeyCount - 1;

        // Find spline segment with `key` ∈ (spline[index - 1], spline[index]].
        const size_t index = GetSplineSegment(key);
        const Coord<size_t> down = spline_points_arr[index - 1];
        const Coord<size_t> up = spline_points_arr[index];

        // Compute slope.
        const double x_diff = up.x - down.x;
        const double y_diff = up.y - down.y;
        const double slope = y_diff / x_diff;

        // Interpolate.
        const double key_diff = key - down.x;
        return std::fma(key_diff, slope, down.y);
    }

    // Returns a search bound [begin, end) around the estimated position.
    std::pair< size_t, size_t> GetSearchBound(size_t key) {
    	size_t estimate = GetEstimatedPosition(key);
    	size_t begin = (estimate < maxSplineErr) ? 0 : (estimate - maxSplineErr);
    	size_t end = (estimate + maxSplineErr + 2 > currKeyCount) ? currKeyCount : (estimate + maxSplineErr + 2);
        return (std::make_pair(begin, end));

    }

    // Returns the size in bytes.
    size_t GetSize() const {
        return sizeof(*this) + getMaxPrefix() * sizeof(uint32_t) + getSplineSize() * sizeof(Coord<size_t>);
    }

private:
    size_t start;
    size_t end;
    size_t numRadixBit;
    size_t numShiftBits;
    size_t maxSplineErr;
    size_t currKeyCount;
    size_t currDistinctKeyCnt;
    size_t prevKey;
    size_t prevKeyPos;
    size_t prevPrefix;
    size_t max_prefix;
    size_t spline_size;
    size_t boundStart;
    size_t boundEnd;
    size_t arrSize;
    //std::vector<din_t> radix_table_;
    //hls::vector< din_t, INPUTSIZE> radix_table_;
    //GEETESH: commented as we are using Top module : buildRadixTable and not entire RS as whole
    din_t radix_table_;
    //Coord<size_t> spline_points_arr[TestNumber];
    Coord<size_t>* spline_points_arr;
    // Current upper and lower limits on the error corridor of the spline.
    Coord<size_t> upperBound;
    Coord<size_t> lowerBound;

    // Previous CDF point.
    Coord<size_t> prev_point_;

};
#endif

