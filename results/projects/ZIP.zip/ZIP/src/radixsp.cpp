#include "./RadixSpline.h"

//using namespace std;
extern "C" {
void radixsp(                                                                            size_t minT,
											 size_t maxT,
											 const unsigned int *in1,
											 size_t vecSizeT,
											 size_t numShiftBitsT,
											 Coord<size_t> *spline_points_arr,
											 din_t &radix_table_, size_t TestNumber )
{
#pragma HLS TOP name=radixsp
//#pragma HLS PIPELINE II=10
	const int c_size = TestNumber;
//#pragma HLS INLINE
	size_t min = minT;
	size_t max = maxT;
	const size_t vecSize = vecSizeT;
	const size_t numShiftBits = numShiftBitsT;
	RadixSpline rs(min, max,vecSize,numShiftBits,spline_points_arr,radix_table_);
radixsp:
	for( int i = 0; i < TestNumber; i++)
	{
//#pragma HLS UNROLL factor=10
#pragma HLS PIPELINE II = 1
#pragma HLS LOOP_TRIPCOUNT min = c_size max = c_size
	    size_t key = in1[i];
	    rs.AddKey(key);
	}
	rs.Finalize();
	//radix_table_ = rs.getRadixTable();
	//spline_points_arr = rs.getSplinePoint();
}
}
