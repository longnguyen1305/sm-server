#define _CRT_SECURE_NO_DEPRECATE 1
#include "xcl2.hpp"
#include "cmdlineparser.h"
#include "./RadixSpline.h"
using namespace sda::utils;

TIMER_INIT(7);

template <typename T, typename U>
bool CanTypeFitValue(const U value) {
    const intmax_t botT = intmax_t(numeric_limits<T>::min());
    const intmax_t botU = intmax_t(numeric_limits<U>::min());
    const uintmax_t topT = uintmax_t(numeric_limits<T>::max());
    const uintmax_t topU = uintmax_t(numeric_limits<U>::max());
    return !((botT > botU && value < static_cast<U> (botT)) || (topT < topU&& value > static_cast<U> (topT)));
}
std::pair<size_t,size_t> setRadixSize(size_t& start, size_t& end)
{
    size_t diff = end - start;
    size_t numShiftBits;
    size_t numRadixBit = 18;
    if (CanTypeFitValue<uint32_t>(diff))
    {
        //std::cout << " number is 32 bit" << " ;clz: " << uint32_t(diff) << " ; numRadixBit: " << numRadixBit << std::endl;
        uint32_t clz = uint32_t(diff);
        if ((32 - clz) < numRadixBit)
        {
            numShiftBits = 0;
        }
        else
        {
            numShiftBits = 32 - numRadixBit - clz;
        }
    }
    else if (CanTypeFitValue<uint64_t>(diff))
    {
        //std::cout << " number is 64 bit" << std::endl;
        numShiftBits = 64 - numRadixBit - diff;
    }
    else
    {
        //std::cout << " number2 is 32 bit" << std::endl;
        uint64_t clz = uint64_t(diff);
        if ((64 - clz) < numRadixBit)
        {
            numShiftBits = 0;
        }
        else
        {
            numShiftBits = 64 - numRadixBit - clz;
        }
    }
    size_t val = ((end - start) >> numShiftBits)+2;
    //std::cout<<"DEBUG: end: " << end << " ;start: " << start << std::endl;

    return (std::make_pair( val,numShiftBits ) );
}
void writeFile( std::string& fileName, std::vector<size_t>& testVector,size_t TestNumber )
{
    ofstream OFILE(fileName);
    //IFILE.open(fileName);
    if( OFILE.is_open())
    {
        for(int i = 0; i < TestNumber; ++i)
        {
            OFILE << testVector[i] ;
	    OFILE << "\n";
            //std::cout<<"DEBUG: i:" << i << " ; data: " << testVector[i] << std::endl;
        }
    }
    OFILE.close();
}
void readFile( std::string& fileName, std::vector<size_t>& testVector,size_t TestNumber )
{
    ifstream IFILE(fileName);
    //IFILE.open(fileName);
    if( IFILE.is_open())
    {
        for(int i = 0; i < TestNumber; ++i)
        {
            IFILE >> testVector[i];
            //std::cout<<"DEBUG: i:" << i << " ; data: " << testVector[i] << std::endl;
        }
    }
    IFILE.close();
}
    // Returns the index of the spline point that marks the end of the spline segment that contains the `key`:
    size_t GetSplineSegment(const size_t key, size_t start, 
		            size_t numShiftBits,din_t radix_table_,
			    Coord<size_t>* spline_points_arr) {
        // Narrow search range using radix table.
        const size_t prefix = (key - start) >> numShiftBits;
        /*
		GEETESH: Commented assertion as :
		WARNING: [HLS 207-4615]
		the argument to '__builtin_assume' has side effects that will be discarded (././RadixSpline.h:70:27)
		*/
        //assert(prefix + 1 < getMaxPrefix());
        const uint32_t begin = radix_table_[prefix];
        const uint32_t end = radix_table_[prefix + 1];

        if (end - begin < 32) {
            // Do linear search over narrowed range.
            uint32_t current = begin;
            /*
            WARNING: [HLS 200-878] Unable to schedule the loop exit test ('icmp' operation ('icmp_ln77', ././RadixSpline.h:77))
            in the first pipeline iteration (II = 1 cycles).
            Resolution: For help on HLS 200-878 see www.xilinx.com/cgi-bin/docs/rdoc?v=2022.1;t=hls+guidance;d=200-878.html
            */
            size_t cmpVal = spline_points_arr[current].x;
            //std::cout<<"DEBUG: cmpVal: " << cmpVal << " ; key: " << key << std::endl;
            while (cmpVal < key)
            {
//#pragma HLS UNROLL
//#pragma HLS pipeline II=1
            	++current;
            	cmpVal = spline_points_arr[current].x;
            }
            //std::cout << " DEBUG: returning Val: " << current << std::endl;
            return current;
        }
        // Do binary search over narrowed range.
        const auto lb1 = std::lower_bound(spline_points_arr+begin,
        		spline_points_arr+end,
				key,
				[](const Coord<size_t>& coord, const size_t key) { return coord.x < key; });
        return std::distance(spline_points_arr,lb1);
    }
    //Now search
    // Returns the estimated position of `key`.
    double GetEstimatedPosition(const size_t key, size_t start, size_t end,
		            size_t numShiftBits,din_t radix_table_,
			    Coord<size_t>* spline_points_arr,size_t currKeyCount) {
        // Truncate to data boundaries.
        if (key <= start) return 0;
        if (key >= end) return currKeyCount - 1;

        // Find spline segment with `key` ∈ (spline[index - 1], spline[index]].
        const size_t index = GetSplineSegment(key,start,numShiftBits,radix_table_,spline_points_arr);
        const Coord<size_t> down = spline_points_arr[index - 1];
        const Coord<size_t> up = spline_points_arr[index];

        // Compute slope.
        const double x_diff = up.x - down.x;
        const double y_diff = up.y - down.y;
        const double slope = y_diff / x_diff;

        // Interpolate.
        const double key_diff = key - down.x;
        return std::fma(key_diff, slope, down.y);
    }

    // Returns a search bound [begin, end) around the estimated position.
    std::pair< size_t, size_t> GetSearchBound(size_t key, size_t start, size_t end,
		            size_t numShiftBits,din_t radix_table_,
			    Coord<size_t>* spline_points_arr,size_t currKeyCount) {
        size_t maxSplineErr = 32;
    	size_t estimate = GetEstimatedPosition(key,start,end,numShiftBits,radix_table_,spline_points_arr,currKeyCount);
    	size_t begin1 = (estimate < maxSplineErr) ? 0 : (estimate - maxSplineErr);
    	size_t end1 = (estimate + maxSplineErr + 2 > currKeyCount) ? currKeyCount : (estimate + maxSplineErr + 2);
        return (std::make_pair(begin1, end1));

    }

//input file is outData.dat
int main(int argc, char** argv) 
{

  // Command Line Parser
  CmdLineParser parser;
  // Switches
  //**************//"<Full Arg>",  "<Short Arg>", "<Description>", "<Default>"
  parser.addSwitch("--xclbin_file", "-x", "input binary file string", "");
  parser.addSwitch("--input_file", "-i", "input test data file", "");
  parser.addSwitch("--key", "-k", "input key to search", "");
  parser.addSwitch("--data_size", "-s", "size of dataset to search into", "");
  parser.parse(argc, argv);
  // Read settings
  std::string binaryFile = parser.value("xclbin_file");
  std::string filename = parser.value("input_file"); 
  size_t key2Search = parser.value_to_int("key");
  size_t TestNumber = parser.value_to_int("data_size");
  if (argc < 6) {
    parser.printHelp();
    return EXIT_FAILURE;
  }
    int returnVal = 0;
    //initialize
    std::vector< size_t > data(TestNumber); //This will be the sorted data vector
    //std::generate(data.begin(), data.end(), std::rand);

    size_t dataSize = TestNumber;
    int nerror = 0;
    readFile(filename,data,TestNumber);
    std::stable_sort(data.begin(), data.end());
    std::string ofilename = "sortData.dat";
    writeFile(ofilename,data,TestNumber);

   size_t minT;
   size_t maxT;
   size_t vecSizeT;
   size_t numShiftBitsT;
   size_t boundStart = 0;
   size_t boundEnd = 0;
   std::vector<int, aligned_allocator<int>> source_in1(TestNumber);
   size_t vector_size_bytes = sizeof(int) * TestNumber;

   for( int i = 0; i < TestNumber; i++)
   {
//#pragma HLS UNROLL
//#pragma HLS LOOP_TRIPCOUNT min = c_size max = c_size
	source_in1[i] = data[i]; 
   }

   size_t min = data.front();
   size_t max = data.back();
   std::pair<size_t, size_t> prepData = setRadixSize(min,max);
   //std::pair<size_t, size_t> prepData = buildRadix(min,max);
   const size_t vecSize = prepData.first;
   const size_t numShiftBits = prepData.second;
   din_t radix_table_;
   Coord<size_t> spline_points_arr[TestNumber];

   minT = min;
   maxT = max;
   vecSizeT = vecSize;
   numShiftBitsT = numShiftBits;

   TIMER_START(1);
   cl_int err;
   cl::Context context;
   cl::Kernel krnl_vector_add;
   cl::CommandQueue q;
   auto devices = xcl::get_xil_devices();
   bool valid_device = false;
   auto fileBuf = xcl::read_binary_file(binaryFile);
   cl::Program::Binaries bins{{fileBuf.data(), fileBuf.size()}};
   for (unsigned int i = 0; i < devices.size(); i++) {
	  auto device = devices[i];
	  // Creating Context and Command Queue for selected Device
	  OCL_CHECK(err, context = cl::Context(device, NULL, NULL, NULL, &err));
	  OCL_CHECK(err, q = cl::CommandQueue(context, device, CL_QUEUE_PROFILING_ENABLE, &err));
	  std::cout << "Trying to program device[" << i << "]: " << device.getInfo<CL_DEVICE_NAME>() << std::endl;
	  cl::Program program(context, {device}, bins, NULL, &err);
	  if (err != CL_SUCCESS) {
		  std::cout << "Failed to program device[" << i << "] with xclbin file!\n";
	  } else {
		  std::cout << "Device[" << i << "]: program successful!\n";
		  OCL_CHECK(err, krnl_vector_add = cl::Kernel(program, "radixsp", &err));
		  valid_device = true;
		  break; // we break because we found a valid device
          }
   }
   if (!valid_device) {
	   std::cout << "Failed to program any device found, exit!\n";
	   exit(EXIT_FAILURE);
   }
  // Allocate Buffer in Global Memory
  // Buffers are allocated using CL_MEM_USE_HOST_PTR for efficient memory and
  // Device-to-host communication
   OCL_CHECK(err, cl::Buffer buffer_in1(
                   context, CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                   vector_size_bytes, source_in1.data(), &err));
   OCL_CHECK(err, cl::Buffer buffer_output1(
                   context, CL_MEM_USE_HOST_PTR | CL_MEM_WRITE_ONLY,
                   vector_size_bytes, &spline_points_arr[0], &err));
   OCL_CHECK(err, cl::Buffer buffer_output2(
                   context, CL_MEM_USE_HOST_PTR | CL_MEM_WRITE_ONLY,
                   vector_size_bytes, &radix_table_, &err));


   OCL_CHECK(err, err = krnl_vector_add.setArg(0, minT));
   OCL_CHECK(err, err = krnl_vector_add.setArg(1, maxT));
   OCL_CHECK(err, err = krnl_vector_add.setArg(2, buffer_in1));
   OCL_CHECK(err, err = krnl_vector_add.setArg(3, vecSizeT));
   OCL_CHECK(err, err = krnl_vector_add.setArg(4, numShiftBitsT));
   OCL_CHECK(err, err = krnl_vector_add.setArg(5, buffer_output1));
   OCL_CHECK(err, err = krnl_vector_add.setArg(6, buffer_output2));
   OCL_CHECK(err, err = krnl_vector_add.setArg(7, TestNumber));

  // Copy input data to device global memory
   OCL_CHECK(err, err = q.enqueueMigrateMemObjects({buffer_in1}, 0 /* 0 means from host*/));
   OCL_CHECK(err, err = q.enqueueTask(krnl_vector_add));
   OCL_CHECK(err, err = q.enqueueMigrateMemObjects({buffer_output1}, CL_MIGRATE_MEM_OBJECT_HOST));
   //OCL_CHECK(err, err = q.enqueueMigrateMemObjects({buffer_output2}, CL_MIGRATE_MEM_OBJECT_HOST));
   //OCL_CHECK(err, err = q.enqueueMigrateMemObjects({buffer_output1,buffer_output2}, CL_MIGRATE_MEM_OBJECT_HOST));
   q.finish();
   TIMER_STOP;
#if 0 
	int myradixSize = sizeof(radix_table_) / sizeof(din_t);
	printf("RadixSize = %d\n", myradixSize);
	for (int i = 0; i < myradixSize; i++) 
	{
		printf("DEBUG: radix_table_: %d\n", radix_table_[i]);
		//std::cout<<"DEBUG: radix_table_: " << radix_table_[i] << std::endl;
	}
	for( int i = 0; i < TestNumber; i++)
	{
		std::cout<<"DEBUG: spline_points_arr[" << i << "]: x = " << spline_points_arr[i].x << " ;y = " << spline_points_arr[i].y << std::endl;
	}
#endif	
   TIMER_START(2);
   std::pair< size_t,  size_t> bound = GetSearchBound(key2Search,minT,maxT,numShiftBitsT,
		                                      radix_table_,spline_points_arr,TestNumber);
   boundStart = bound.first;
   boundEnd = bound.second;
   auto start = data.begin() + boundStart;
   auto last = data.begin() + boundEnd;
   auto resultPos = std::lower_bound(start, last, key2Search) - data.begin();
   TIMER_STOP;
   bool match = true;
   if( key2Search == data[resultPos] )
   {
           std::cout << "boundStart: " << boundStart << " ;boundEnd: " << boundEnd << std::endl;
	   std::cout << "FOUND: " << key2Search << " at Pos: " << resultPos << std::endl;
   }
   else
   {
	   std::cout << "KEY " << key2Search << " not found!" << std::endl;
	   match = false;
   }

  printf("------------------------------------------------------\n");
  printf("  Performance Summary                                 \n");
  printf("------------------------------------------------------\n");
  printf("  RadixSplineIndex Build Time          : %12.4f ms\n", TIMER_REPORT_MS(1));
  printf("  Lookup Time                          : %12.4f ms\n", TIMER_REPORT_MS(2));
  printf("------------------------------------------------------\n");

  return (match ? EXIT_SUCCESS : EXIT_FAILURE);
}

